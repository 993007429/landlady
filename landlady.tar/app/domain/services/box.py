import enum
import tarfile
import typing
import zipfile
from typing import Optional, List

from sqlalchemy import desc

from app.db.models.box import Box
from app.domain.entities.box import BoxEntity
from app.domain.services.base import BaseService
from app.infra.repository import RepoQuery, PageParams
from app.domain.services import errors


class BoxOperation(enum.Enum):
    apply = '1'
    free = '2'


class BoxService(BaseService):

    def get_box(self, box_id: int) -> Optional[BoxEntity]:
        box = self._repo_generator(Box).get(box_id)
        if not box:
            return None
        return self.entity_adapter.to_box_entity(box)

    def get_all_boxes(self, offset: int = 0, limit: int = 20) -> List[BoxEntity]:
        boxes = self._repo_generator(Box).get_models_by_query(
            RepoQuery(
                order_by=[(Box.id, desc)],
                page_params=PageParams(offset=offset, limit=limit)
            )
        )
        return [self.entity_adapter.to_box_entity(box) for box in boxes if box]

    def operate_box(self, box_id: int, user_id: int, operation: BoxOperation) -> Optional[BoxEntity]:
        repo = self._repo_generator(Box)
        box = repo.get(box_id)
        if not box:
            raise errors.EntityDoesNotExist(box_id)

        if operation == BoxOperation.apply:
            if box.user_id:
                raise errors.BoxUnavailableException(box_id)
            box.user_id = user_id
        else:
            if not box.user_id or user_id != box.user_id:
                raise errors.InvalidOperationException()
            box.user_id = 0

        repo.save(box)
        return self.get_box(box_id)

    def deploy_in_box(self, box_id: int, user_id: int, file: typing.IO):
        box = self.get_box(box_id)
        if not box:
            raise errors.EntityDoesNotExist(box_id)

        if not box.user or box.user.id != user_id:
            raise errors.InvalidOperationException()

        tar = tarfile.TarFile(file)
        tar.extractall(box.code_dir)
