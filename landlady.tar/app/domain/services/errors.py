class EntityDoesNotExist(Exception):
    """Raised when entity was not found in database."""
    def __init__(self, entity_id):
        self.entity_id = entity_id


class BoxUnavailableException(Exception):
    """
    box不可用
    """
    def __init__(self, entity_id):
        self.entity_id = entity_id


class InvalidOperationException(Exception):
    """
    无效操作
    """