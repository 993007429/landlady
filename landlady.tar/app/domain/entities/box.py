from datetime import datetime
from typing import Optional

from app.config import BOX_ROOT
from app.domain.entities.project import ProjectEntity
from app.domain.entities.rwmodel import RWModel
from app.domain.entities.user import UserEntity


class BoxEntity(RWModel):
    id: int
    project: Optional[ProjectEntity] = None
    user: Optional[UserEntity] = None
    start_time: Optional[datetime] = None

    @property
    def code_dir(self):
        return f'{BOX_ROOT}/{self.project.name}/box-{self.id}'
