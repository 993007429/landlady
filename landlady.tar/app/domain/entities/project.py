from app.domain.entities.rwmodel import RWModel


class ProjectEntity(RWModel):
    id: int
    name: str
