from typing import TypeVar

from sqlmodel import SQLModel

M = TypeVar('M', bound=SQLModel)
