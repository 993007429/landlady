import enum
from typing import Optional
from datetime import datetime

from sqlalchemy import Column, Enum
from sqlmodel import Field, SQLModel

from app.db.models.common import DateTimeModelMixin


class BoxStatus(enum.Enum):
    off = 0
    on = 1
    error = 2


class Box(SQLModel, DateTimeModelMixin, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    project_id: int
    user_id: int
    status: BoxStatus = Field(sa_column=Column(Enum(BoxStatus)))
    start_time: datetime = None
