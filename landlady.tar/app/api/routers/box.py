from typing import Optional

from fastapi import APIRouter, Query, Depends, HTTPException, UploadFile, File

from app.api.dependencies.authentication import get_current_user_authorizer
from app.api.schemas.box import BoxResponse
from app.api.schemas.common import ModelListResponse, SuccessResponse
from app.domain.entities.box import BoxEntity
from app.db.models.user import User
from app.domain.services.factory import ServiceFactory
from app.resources import strings

from app.domain.services import errors
from app.domain.services.box import BoxService, BoxOperation

router = APIRouter()


@router.get(
    "/boxes",
    response_model=ModelListResponse[BoxEntity],
    name="box:get-all-boxes",
)
async def get_all_boxes(
        limit: int = Query(20, ge=1),
        offset: int = Query(0, ge=0),
        box_service: BoxService = Depends(ServiceFactory.dependency(BoxService))) -> ModelListResponse[BoxEntity]:
    boxes = box_service.get_all_boxes(offset, limit)
    return ModelListResponse(
        list=boxes,
        start=offset,
        perpage=limit,
        total=len(boxes)
    )


@router.put(
    '/boxes/{box_id}',
    response_model=BoxResponse,
    name='box:update-box',
)
async def update_box(
        box_id: int,
        operation: BoxOperation,
        current_user: Optional[User] = Depends(get_current_user_authorizer()),
        box_service: BoxService = Depends(ServiceFactory.dependency(BoxService))) -> BoxResponse:

    box, error_msg = None, None
    try:
        box = box_service.operate_box(box_id=box_id, user_id=current_user.id, operation=operation)
    except errors.EntityDoesNotExist:
        error_msg = strings.BOX_NOT_EXIST
    except errors.BoxUnavailableException:
        error_msg = strings.BOX_UNAVAILABLE
    except errors.InvalidOperationException:
        error_msg = strings.INVALID_OPERATION
    finally:
        if box:
            res = BoxResponse(box=box)
            return res
        else:
            raise HTTPException(
                status_code=400,
                detail=error_msg or '操作失败',
            )


@router.post(
    "/boxes/{box_id}/upload",
    response_model=SuccessResponse,
    name="box:upload-in-box",
)
async def upload_in_box(
        box_id: int,
        file: UploadFile = File(...),
        current_user: Optional[User] = Depends(get_current_user_authorizer()),
        box_service: BoxService = Depends(ServiceFactory.dependency(BoxService))) -> SuccessResponse:
    err_msg = None
    try:
        box_service.deploy_in_box(box_id, current_user.id, file.file)
    except errors.EntityDoesNotExist:
        err_msg = strings.BOX_NOT_EXIST
    except errors.InvalidOperationException:
        err_msg = strings.INVALID_OPERATION
    finally:
        if err_msg:
            raise HTTPException(
                status_code=400,
                detail=err_msg or '操作失败',
            )
        else:
            return SuccessResponse()
