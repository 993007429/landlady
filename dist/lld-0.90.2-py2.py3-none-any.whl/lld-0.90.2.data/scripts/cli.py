import os

import click
import requests
import sseclient
from prettytable import PrettyTable

from app.config import JWT_TOKEN_PREFIX
from client.config import DEPLOY_ENDPOINT, JWT_TOKEN
from client.packing import make_targz


class CLI(object):
    def __init__(self, command: str, arg1: str, arg2: str):
        self.command = command
        self.arg1 = arg1
        self.arg2 = arg2

    def __call__(self):
        print(self.command)
        if self.command == 'box':
            if self.arg1 == 'list':
                list_box()
        elif self.command == 'deploy':
            box_id = self.arg1
            if not box_id:
                print('请指定box_id')
            deploy_in_box(int(box_id))
        elif self.command == 'log':
            box_id = self.arg1
            if not box_id:
                print('请指定box_id')
            fetch_log(int(box_id))


def list_box():
    url = f'{DEPLOY_ENDPOINT}/boxes'
    resp = requests.get(url)
    result = resp.json()
    pt = PrettyTable(['box_id', '使用人', '开始时间', 'status'])
    for box in result.get('list', []):
        pt.add_row([box['id'], (box.get('user') or {}).get('name', '空闲'), box['startTime'] or '', box['status']])
    print(pt)


def deploy_in_box(box_id: int):
    current_dir = os.getcwd()
    filename = f'{current_dir}/bundle.tar.gz'
    make_targz(filename, current_dir)

    url = f'{DEPLOY_ENDPOINT}/boxes/{box_id}/upload'
    files = {'file': open(filename, 'rb')}

    r = requests.post(url, files=files)
    print(r.json())


def fetch_log(box_id: int):
    url = f'{DEPLOY_ENDPOINT}/boxes/{box_id}/app_log?process_num=0'
    headers = {
        'Accept': 'text/event-stream',
        'Authorization': f'{JWT_TOKEN_PREFIX} {JWT_TOKEN}'}
    response = requests.get(url, stream=True, headers=headers)
    client = sseclient.SSEClient(response)
    for event in client.events():
        if event.event == 'message':
            print(event.data)


@click.command()
@click.argument('command')
@click.argument('arg1')
# @click.argument('arg2', nargs=1)
def main(command, arg1, arg2=None):
    cli = CLI(command, arg1, arg2)
    cli()


if __name__ == '__main__':
    main()
